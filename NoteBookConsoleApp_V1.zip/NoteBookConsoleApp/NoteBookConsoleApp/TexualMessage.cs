﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoteBookConsoleApp
{
    internal class TexualMessage : IPageable
    {
        protected PageData myData;
        protected string message;
        /// <summary>
        ///     input method for TexualMessage from IPageable uses a Console.WriteLine() to tell user to input their text;
        ///     has Console.ReadLine() that updates the variable myData.author , myData.title , and message;
        /// </summary>
        /// <returns>
        ///     an IPageable 
        /// </returns>
        public virtual IPageable Input()
        {
            Console.WriteLine("Please input your name");
            myData.author = Console.ReadLine();
            Console.WriteLine("please put in message title");
            myData.title = Console.ReadLine();
            Console.WriteLine("please put in the message");
            message = Console.ReadLine();
            return this;
        }

        public void Output()
        {
            Console.WriteLine();
            Console.WriteLine("/-------------------- Message --------------------\\");
            Console.WriteLine($"Title: {myData.title}");
            Console.WriteLine($"Author: {myData.author}");
            Console.WriteLine("Message Content: \n \n" + $"{message}");
            Console.WriteLine("/-------------------- End --------------------\\");
        }

        public PageData MyData {
            get {
                return myData;
            }
            set {
                myData = value;
            }
        }
    }
}
