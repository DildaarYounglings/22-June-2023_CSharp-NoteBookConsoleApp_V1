﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoteBookConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            NoteBook noteBook = new NoteBook();
            const string ExitProgrameKeyword = "exit";
            string commandPrompt = $"Please enter {noteBook.show} , {noteBook.delete}, or {noteBook._new}.";
            Console.WriteLine(NoteBook.IntroMessage);
            Console.WriteLine(commandPrompt);
            string input = "";
            do
            {
                input = Console.ReadLine();
                string[] commands = input.Split();
                try
                {
                    // get the first command...show, new, or delete
                    // and pass the second command to the functions
                    noteBook[commands[0]]((commands.Length > 1) ? commands[1] : "");
                }catch(KeyNotFoundException e)
                {
                    if(input != ExitProgrameKeyword)
                    {
                        Console.WriteLine($"{commandPrompt}");
                    }
                    
                }
                

            } while (input != "exit" );
            Console.WriteLine(NoteBook.OutroMessage);
        }
    }
}