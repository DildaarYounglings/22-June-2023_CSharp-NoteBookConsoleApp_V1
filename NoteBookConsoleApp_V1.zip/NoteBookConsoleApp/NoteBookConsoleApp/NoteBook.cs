﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoteBookConsoleApp
{
    /// <summary>
    ///     a class called NoteBook that has methods
    /// </summary>
    internal class NoteBook
    {
        /// <summary>
        ///     the const string var called IntroMessage
        /// </summary>
        public const string IntroMessage = "Welcome to the Console App that is a NoteBook v1";

        /// <summary>
        ///     the const string var called OutroMessage
        /// </summary>
        public const string OutroMessage = "Dev says: 'Thanks for beta viewing v1' ";

        List<IPageable> pages = new List<IPageable>();
        public delegate void SimpleFuntion(string command);
        private Dictionary<string,SimpleFuntion> commandLineArgs = new Dictionary<string, SimpleFuntion>();
        public readonly string show = "show", _new = "new",delete = "delete";
        public SimpleFuntion this[string command] {
            get {
                return commandLineArgs[command];
            }
        }
        public NoteBook()
        {
            commandLineArgs.Add(show, Show);
            commandLineArgs.Add(_new, New);
            commandLineArgs.Add(delete, Delete);
        }
        /// <summary>
        ///     Creates a new notebook with Input keywords for commands
        /// </summary>
        /// <param name="commandLineKeywords">
        ///     index 0 = show, 1 = new, 2 = delete
        /// </param>
        public NoteBook(params string[] commandLineKeywords) : this ()
        {
            for (int i = 0; i < commandLineKeywords.Length; i++)
            {
                if (commandLineKeywords[i] == "")
                {
                    continue;
                }
                switch (i)
                {
                    case 0:
                        commandLineArgs.Remove(show);
                        commandLineArgs.Add(show = commandLineKeywords[i],Show);
                        break;

                    case 1:
                        commandLineArgs.Remove(_new);
                        commandLineArgs.Add(_new = commandLineKeywords[i], New);
                        break;

                    case 2:
                        commandLineArgs.Remove(delete);
                        commandLineArgs.Add(delete = commandLineKeywords[i], Delete);
                       break;
                }
            }

        }
        private void Show(string command)
        {
            switch (command)
            {
                case "":
                    Console.WriteLine("Show commands:");
                    Console.WriteLine("pages        show all pages");
                    Console.WriteLine("id of page       show a page with the specific id");
                    Console.WriteLine("image        create a new image page");
                    break;

                case "pages":
                    Console.WriteLine("showing all pages");
                    for (int i = 0; i < pages.Count; ++i)
                    {
                        Console.WriteLine($"ID: {i}; {pages[i].MyData.title}");
                    }
                    break;

                default:
                    int number;
                    if(int.TryParse(command, out number))
                    {
                        Console.WriteLine($"showing page {number}");

                        if(number < pages.Count)
                        {
                            pages[number].Output();
                        }
                    }
                    break;
            }
        }
        private void New(string command)
        {
            switch (command)
            {
                case "":
                    Console.WriteLine("New commands:");
                    Console.WriteLine("message      create a new message page");
                    Console.WriteLine("list     create a new list page");
                    Console.WriteLine("image    create a new image page");
                    break;

                case "message":
                    Console.WriteLine("creating message");
                    pages.Add(new TexualMessage().Input());
                    break;

                case "list":
                    Console.WriteLine("creating list");
                    break;

                case "image":
                    Console.WriteLine("creating image");
                    break;
            }
        }
        private void Delete(string command)
        {
            switch (command)
            {
                case "":
                    Console.WriteLine("Delete commands:");
                    Console.WriteLine("all      create a new message page");
                    Console.WriteLine("id of page     create a new list page");
                    break;

                case "all":
                    Console.WriteLine("deleted all pages");
                    break;

                default:
                    Console.WriteLine("creating list");
                    break;

            }
        }
    }
}
