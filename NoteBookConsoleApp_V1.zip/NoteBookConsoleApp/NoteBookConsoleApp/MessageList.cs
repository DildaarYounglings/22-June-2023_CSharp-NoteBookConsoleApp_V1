﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoteBookConsoleApp
{
    internal class MessageList : TexualMessage
    {
        private enum BulletType { Dashed, Numbered, Star }
        private BulletType bulletType;
        /// <summary>
        ///     is the override of the TexualMessage class method IPageable Input()
        /// </summary>
        /// <returns>
        ///     returns this which is the MessageList class
        /// </returns>
        public override IPageable Input()
        {
            return this;
        }
    }
}
